import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


class GeminiAPIError(RuntimeError):
    """Raised when the Gemini API request fails or returns unusable content."""


def generate_content(api_key, model, contents, timeout=90):
    api_key = (api_key or "").strip()
    model = (model or "gemini-2.5-flash").strip()
    if not api_key:
        raise GeminiAPIError("Une clé API Gemini est requise.")

    url = (
        "https://generativelanguage.googleapis.com/v1beta/"
        f"models/{quote(model, safe='-_.')}:generateContent"
    )
    request = Request(
        url,
        data=json.dumps({"contents": contents}).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-goog-api-key": api_key,
        },
        method="POST",
    )

    try:
        with urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        try:
            details = json.loads(exc.read().decode("utf-8"))
            message = details.get("error", {}).get("message", "Gemini a refusé la requête.")
        except (TypeError, ValueError, UnicodeDecodeError):
            message = "Gemini a refusé la requête. Vérifie la clé, le modèle et les quotas."
        raise GeminiAPIError(message) from None
    except URLError as exc:
        raise GeminiAPIError(f"Connexion Gemini impossible : {exc.reason}") from None
    except TimeoutError:
        raise GeminiAPIError("Gemini n’a pas répondu dans le délai prévu.") from None
    except (UnicodeDecodeError, ValueError, TypeError):
        raise GeminiAPIError("La réponse de Gemini n’est pas un JSON valide.") from None

    try:
        candidate = payload["candidates"][0]
        text_parts = []
        for part in candidate["content"].get("parts", []):
            if isinstance(part, dict) and "text" in part:
                text_parts.append(part["text"])
        text = "\n".join(text_parts).strip()
    except (KeyError, IndexError, TypeError):
        raise GeminiAPIError("Gemini n’a renvoyé aucune réponse exploitable.") from None

    if not text:
        raise GeminiAPIError("Gemini a renvoyé une réponse vide.")
    return text
