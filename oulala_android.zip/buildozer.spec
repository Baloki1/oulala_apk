[app]

# (str) Title of your application
title = Oulala AI

# (str) Package name
package.name = oulalaai

# (str) Package domain (needed for android/aidl)
domain = com.oulala

# (str) Source code where the main.py live
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,jpg,jpeg,kv,atlas

# (list) List of inclusions using pattern matching
source.include_patterns = assets/*,images/*

# (list) List of exclusions using pattern matching
source.exclude_patterns = tests/*, .git/*

# (str) Application versioning (method 1)
version = 1.0.0

# (list) Application requirements
requirements = python3,kivy==2.3.1,plyer

# (str) Presplash of the application
# presplash.filename = %(source.dir)s/assets/presplash.png

# (str) Icon of the application
# icon.filename = %(source.dir)s/assets/icon.png

# (str) Supported orientation (one of landscape, portrait or all)
orientation = portrait

# (bool) Indicate if the application should be fullscreen or not
fullscreen = 0

# (list) Permissions
android.permissions = INTERNET

# (int) Target Android API, should be as high as possible
android.api = 35

# (int) Minimum API your APK will support
android.minapi = 23

# (str) Android logcat filters to use
android.logcat_filters = *:S python:D

# (bool) If True, then skip trying to build the package
# skip.build = False

# (bool) If True, then only package and not build what is necessary
# skip.compile = False

# (list) Android archs to build for
android.archs = arm64-v8a

# (str) The Android SDK directory
# android.sdk_path =

# (str) The Android NDK directory
# android.ndk_path =

# (str) The Android build tools version
# android.build_tools = 35.0.0

# (str) The Android entry point
# android.entrypoint = org.kivy.android.PythonActivity

# (str) The Android package name
# android.package =

# (str) The Android app theme
# android.theme = @android:style/Theme.NoTitleBar

[buildozer]
# (int) Log level (0 = quiet, 1 = info, 2 = debug)
log_level = 2

# (int) Display warning level (0 = quiet, 1 = info, 2 = debug)
warn_on_root = 1

# (int) Build mode: 0 = release, 1 = debug
debug = 1
