# Oulala AI Android

Application Android Kivy pour converser avec l'API Gemini.

## Structure

- `main.py` : interface utilisateur Kivy premium
- `gemini_api.py` : client HTTP Gemini
- `buildozer.spec` : configuration de build Android
- `tests/test_gemini_api.py` : tests du client Gemini

## Lancement local

```bash
python -m pip install kivy
python main.py
```

## Génération APK via Colab

1. Ouvre le notebook de build si disponible.
2. Uploade ce dossier en zip.
3. Exécute les étapes du notebook : installation de Buildozer, build APK, téléchargement du `.apk`.

## Variables importantes

- `api_key` : clé Google Generative AI
- `model` : modèle Gemini, par exemple `gemini-2.5-flash`

## Permissions Android

- `INTERNET` pour joindre l'API Gemini
- accès aux fichiers images selon le système de sélection
