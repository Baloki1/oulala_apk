import base64
import mimetypes
import os
import threading
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Ellipse, Rectangle, RoundedRectangle
from kivy.metrics import dp, sp
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.modalview import ModalView
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.utils import platform

from gemini_api import GeminiAPIError, generate_content

APP_TITLE = "Oulala AI"
DEFAULT_MODEL = "gemini-2.5-flash"
MAX_IMAGE_BYTES = 10 * 1024 * 1024

BG = (0.05, 0.08, 0.14, 1.0)
BG_2 = (0.09, 0.13, 0.21, 1.0)
SURFACE = (0.13, 0.20, 0.27, 1.0)
SURFACE_2 = (0.18, 0.24, 0.33, 1.0)
PANEL = (0.23, 0.31, 0.42, 1.0)
MUTED = (0.70, 0.79, 0.87, 1.0)
TEXT = (0.97, 0.99, 1.0, 1.0)
PRIMARY = (0.20, 0.82, 0.88, 1.0)
USER = (0.17, 0.30, 0.47, 1.0)
ASSISTANT = (0.99, 1.00, 1.00, 1.0)
ERROR = (1.0, 0.79, 0.77, 1.0)


class PremiumMobileApp(App):
    title = APP_TITLE

    def build(self):
        Window.clearcolor = BG
        self.api_key = ""
        self.model = DEFAULT_MODEL
        self.history = []
        self.image_path = None
        self.busy = False
        self.activity_module = None

        root = BoxLayout(orientation="vertical")
        self.root = root
        with root.canvas.before:
            Color(*BG)
            Rectangle(pos=root.pos, size=root.size)
            Color(0.18, 0.62, 0.88, 0.22)
            self.glow_a = Ellipse(pos=(root.center_x - dp(180), root.center_y - dp(180)), size=(dp(360), dp(360)))
            Color(0.42, 0.28, 0.96, 0.15)
            self.glow_b = Ellipse(pos=(root.center_x + dp(40), root.center_y - dp(120)), size=(dp(280), dp(280)))

        root.padding = (dp(14), dp(12), dp(14), dp(12))
        root.spacing = dp(10)
        root.bind(size=lambda instance, value: self._update_glows(instance, value))

        header = BoxLayout(size_hint_y=None, height=dp(54), spacing=dp(10))
        with header.canvas.before:
            Color(*SURFACE)
            RoundedRectangle(pos=header.pos, size=header.size, radius=[dp(20)])
        header.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )

        title_box = BoxLayout(size_hint_x=1)
        title = Label(
            text="[b]oulala ai[/b]",
            markup=True,
            color=TEXT,
            font_size=sp(25),
            halign="left",
            valign="middle",
        )
        title.bind(size=lambda widget, size: setattr(widget, "text_size", size))
        title_box.add_widget(title)
        header.add_widget(title_box)

        self.new_chat_button = self._pill_button("Nouveau", secondary=True)
        self.new_chat_button.bind(on_release=lambda *_: self.reset_chat())
        header.add_widget(self.new_chat_button)

        self.settings_button = self._pill_button("Clé", secondary=True)
        self.settings_button.bind(on_release=lambda *_: self.open_settings())
        header.add_widget(self.settings_button)
        root.add_widget(header)

        self.status = Label(
            text="Configure ta clé Gemini pour démarrer.",
            color=MUTED,
            font_size=sp(12),
            size_hint_y=None,
            height=dp(24),
            halign="left",
            valign="middle",
        )
        self.status.bind(size=lambda widget, size: setattr(widget, "text_size", (size[0], None)))
        root.add_widget(self.status)

        self.scroll = ScrollView(do_scroll_x=False, bar_width=dp(4), bar_color=(0.5, 0.7, 0.9, 0.7), bar_inactive_color=(0.5, 0.7, 0.9, 0.2))
        self.messages = BoxLayout(
            orientation="vertical",
            spacing=dp(10),
            size_hint_y=None,
            padding=(0, dp(4), 0, dp(10)),
        )
        self.messages.bind(minimum_height=self.messages.setter("height"))
        self.scroll.add_widget(self.messages)
        root.add_widget(self.scroll)

        self._add_message("Oulala", "Bonjour ! Pose-moi une question ou ajoute une image.", role="assistant")

        self.prompt_chip = Label(
            text="IA premium",
            color=PRIMARY,
            font_size=sp(10),
            size_hint=(None, None),
            width=dp(90),
            height=dp(22),
            halign="center",
            valign="middle",
        )
        with self.prompt_chip.canvas.before:
            Color(0.18, 0.39, 0.60, 0.22)
            RoundedRectangle(pos=self.prompt_chip.pos, size=self.prompt_chip.size, radius=[dp(10)])
        self.prompt_chip.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )
        root.add_widget(self.prompt_chip)

        composer = BoxLayout(size_hint_y=None, height=dp(66), spacing=dp(8))
        with composer.canvas.before:
            Color(*SURFACE)
            RoundedRectangle(pos=composer.pos, size=composer.size, radius=[dp(22)])
        composer.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )

        self.image_button = self._icon_button("Image", secondary=True)
        self.image_button.bind(on_release=lambda *_: self.choose_image())
        composer.add_widget(self.image_button)

        self.input = TextInput(
            hint_text="Écris ton message…",
            multiline=False,
            foreground_color=TEXT,
            hint_text_color=MUTED,
            background_color=(0.0, 0.0, 0.0, 0.0),
            cursor_color=PRIMARY,
            padding=(dp(12), dp(15)),
            font_size=sp(16),
            write_tab=False,
        )
        self.input.bind(on_text_validate=lambda *_: self.send_message())
        composer.add_widget(self.input)

        self.send_button = self._send_button()
        self.send_button.bind(on_release=lambda *_: self.send_message())
        composer.add_widget(self.send_button)
        root.add_widget(composer)

        return root

    def on_start(self):
        if platform == "android":
            try:
                from android import activity
                self.activity_module = activity
                activity.bind(on_activity_result=self._on_activity_result)
            except ImportError:
                self.status.text = "Les fonctions Android ne sont pas disponibles ici."

    def on_stop(self):
        if self.activity_module is not None:
            try:
                self.activity_module.unbind(on_activity_result=self._on_activity_result)
            except Exception:
                pass

    def reset_chat(self):
        self.history = []
        self.messages.clear_widgets()
        self.image_path = None
        self.image_button.text = "Image"
        self.input.text = ""
        self._add_message("Oulala", "Nouveau chat. Pose-moi ta prochaine question.", role="assistant")
        self.status.text = "Conversation réinitialisée."

    def _pill_button(self, text, secondary=False):
        btn = Button(
            text=text,
            font_size=sp(12),
            background_normal="",
            background_down="",
            size_hint_x=None,
            width=dp(68),
            height=dp(34),
            color=TEXT,
        )
        with btn.canvas.before:
            Color(*PANEL if secondary else PRIMARY)
            RoundedRectangle(pos=btn.pos, size=btn.size, radius=[dp(14)])
        btn.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )
        return btn

    def _icon_button(self, text, secondary=False):
        btn = Button(
            text=text,
            font_size=sp(12),
            background_normal="",
            background_down="",
            size_hint_x=None,
            width=dp(86),
            height=dp(40),
            color=TEXT,
        )
        with btn.canvas.before:
            Color(*(PANEL if secondary else PRIMARY))
            RoundedRectangle(pos=btn.pos, size=btn.size, radius=[dp(16)])
        btn.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )
        return btn

    def _send_button(self):
        btn = Button(
            text="Envoyer",
            font_size=sp(13),
            background_normal="",
            background_down="",
            size_hint_x=None,
            width=dp(110),
            height=dp(42),
            color=(0.04, 0.08, 0.12, 1),
        )
        with btn.canvas.before:
            Color(*PRIMARY)
            RoundedRectangle(pos=btn.pos, size=btn.size, radius=[dp(18)])
        btn.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )
        return btn

    def open_settings(self):
        modal = ModalView(size_hint=(0.92, None), height=dp(320), auto_dismiss=False)
        panel = BoxLayout(orientation="vertical", padding=dp(18), spacing=dp(12))
        with panel.canvas.before:
            Color(*BG_2)
            RoundedRectangle(pos=panel.pos, size=panel.size, radius=[dp(24)])
        panel.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )

        title = Label(text="Connexion Gemini", color=TEXT, font_size=sp(18), size_hint_y=None, height=dp(30))
        panel.add_widget(title)
        panel.add_widget(Label(
            text="La clé reste seulement en mémoire pendant cette session.",
            color=MUTED,
            font_size=sp(12),
            size_hint_y=None,
            height=dp(35),
        ))

        key_input = TextInput(
            hint_text="Clé API Gemini",
            password=True,
            multiline=False,
            size_hint_y=None,
            height=dp(48),
            foreground_color=TEXT,
            background_color=(0.0, 0.0, 0.0, 0.0),
            hint_text_color=MUTED,
            cursor_color=PRIMARY,
        )
        model_input = TextInput(
            text=self.model,
            hint_text="Modèle Gemini",
            multiline=False,
            size_hint_y=None,
            height=dp(48),
            foreground_color=TEXT,
            background_color=(0.0, 0.0, 0.0, 0.0),
            hint_text_color=MUTED,
            cursor_color=PRIMARY,
        )

        for entry in (key_input, model_input):
            with entry.canvas.before:
                Color(*SURFACE_2)
                RoundedRectangle(pos=entry.pos, size=entry.size, radius=[dp(16)])
            entry.bind(
                pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
                size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
            )

        panel.add_widget(key_input)
        panel.add_widget(model_input)

        actions = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(10))
        cancel = self._pill_button("Annuler", secondary=True)
        cancel.size_hint_x = 1
        cancel.bind(on_release=lambda *_: modal.dismiss())
        save = self._pill_button("Valider")
        save.size_hint_x = 1

        def save_settings(*_):
            key = key_input.text.strip()
            model = model_input.text.strip()
            if not key or not model:
                self.status.text = "Saisis une clé API et un modèle."
                return
            self.api_key = key
            self.model = model
            self.status.text = f"Prêt · modèle {self.model}."
            modal.dismiss()

        save.bind(on_release=save_settings)
        actions.add_widget(cancel)
        actions.add_widget(save)
        panel.add_widget(actions)
        modal.add_widget(panel)
        modal.open()

    def choose_image(self):
        if platform == "android":
            try:
                from plyer import filechooser
                filechooser.open_file(
                    on_selection=self._on_image_selected,
                    filters=["*.png", "*.jpg", "*.jpeg", "*.webp"],
                )
            except Exception as error:
                self.status.text = f"Impossible d’ouvrir les images : {error}"
            return

        try:
            from tkinter import filedialog
            selected = filedialog.askopenfilename(
                title="Choisir une image",
                filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")],
            )
        except Exception:
            selected = ""
        if selected:
            self._on_image_selected([selected])

    def _on_image_selected(self, selection):
        if not selection:
            return
        path = str(selection[0])
        if not os.path.isfile(path):
            self.status.text = "Le fichier sélectionné est invalide."
            return
        if os.path.getsize(path) > MAX_IMAGE_BYTES:
            self.status.text = "L’image est trop lourde (10 Mo max)."
            return
        mime_type, _ = mimetypes.guess_type(path)
        if mime_type not in {"image/png", "image/jpeg", "image/webp"}:
            self.status.text = "Formats acceptés : PNG, JPEG ou WebP."
            return
        self.image_path = path
        self.image_button.text = "Image OK"
        self.status.text = f"Image jointe : {Path(path).name}"

    def send_message(self):
        if self.busy:
            return

        prompt = self.input.text.strip()
        image_path = self.image_path
        if not prompt and not image_path:
            return
        if not self.api_key:
            self.open_settings()
            self.status.text = "Ajoute ta clé Gemini pour continuer."
            return

        parts = []
        if prompt:
            parts.append({"text": prompt})
        if image_path:
            try:
                mime_type, _ = mimetypes.guess_type(image_path)
                image_data = Path(image_path).read_bytes()
                parts.append({
                    "inline_data": {
                        "mime_type": mime_type or "image/jpeg",
                        "data": base64.b64encode(image_data).decode("ascii"),
                    }
                })
            except OSError as error:
                self.status.text = f"Lecture de l’image impossible : {error}"
                return

        user_entry = {"role": "user", "parts": parts}
        self.history.append(user_entry)
        self._add_message("Vous", prompt or "Analyse de l’image…", role="user")
        if image_path:
            self._add_message("Image", Path(image_path).name, role="user")

        self.input.text = ""
        self.image_path = None
        self.image_button.text = "Image"

        self.busy = True
        self.send_button.disabled = True
        self.status.text = "Réflexion en cours…"

        threading.Thread(target=self._request_answer, daemon=True).start()

    def _request_answer(self):
        try:
            text = generate_content(self.api_key, self.model, self.history)
            Clock.schedule_once(lambda _dt, response=text: self._show_answer(response), 0)
        except GeminiAPIError as error:
            Clock.schedule_once(lambda _dt, msg=str(error): self._show_error(msg), 0)

    def _show_answer(self, text):
        self.history.append({"role": "model", "parts": [{"text": text}]})
        self._add_message("Oulala", text, role="assistant")
        self._finish_request("Réponse reçue.")

    def _show_error(self, error):
        self._add_message("Erreur", error, role="error")
        self._finish_request("Erreur d’envoi. Vérifie la clé ou la connexion.")

    def _finish_request(self, status):
        self.busy = False
        self.send_button.disabled = False
        self.status.text = status

    def _add_message(self, sender, text, role):
        anchor = AnchorLayout(
            anchor_x="right" if role == "user" else "left",
            size_hint_y=None,
            height=dp(70),
        )

        bubble = BoxLayout(
            orientation="vertical",
            size_hint=(None, None),
            width=max(dp(180), min(Window.width - dp(68), dp(600))),
            height=dp(58),
            padding=(dp(12), dp(10)),
        )

        if role == "user":
            bubble_color = USER
        elif role == "assistant":
            bubble_color = ASSISTANT
        elif role == "error":
            bubble_color = ERROR
        else:
            bubble_color = ASSISTANT

        with bubble.canvas.before:
            Color(*bubble_color)
            RoundedRectangle(pos=bubble.pos, size=bubble.size, radius=[dp(18)])
        bubble.bind(
            pos=lambda widget, value: setattr(widget.canvas.before.children[0], "pos", value),
            size=lambda widget, value: setattr(widget.canvas.before.children[0], "size", value),
        )

        label = Label(
            text=f"{sender}\n{text}",
            color=(0.04, 0.08, 0.15, 1),
            font_size=sp(14),
            halign="left",
            valign="middle",
            size_hint=(1, 1),
        )
        label.bind(size=lambda widget, size: setattr(widget, "text_size", (size[0], None)))
        label.bind(texture_size=lambda widget, size: self._resize_bubble(anchor, bubble, size))
        bubble.add_widget(label)
        anchor.add_widget(bubble)
        self.messages.add_widget(anchor)
        Clock.schedule_once(lambda _dt: setattr(self.scroll, "scroll_y", 0), 0)

    def _update_glows(self, instance, value):
        if hasattr(self, "glow_a"):
            self.glow_a.pos = (instance.center_x - dp(180), instance.center_y - dp(180))
            self.glow_a.size = (dp(360), dp(360))
        if hasattr(self, "glow_b"):
            self.glow_b.pos = (instance.center_x + dp(40), instance.center_y - dp(120))
            self.glow_b.size = (dp(280), dp(280))

    @staticmethod
    def _resize_bubble(anchor, bubble, texture_size):
        target_height = min(dp(300), max(dp(62), texture_size[1] + dp(16)))
        bubble.height = target_height
        anchor.height = target_height + dp(10)


if __name__ == "__main__":
    PremiumMobileApp().run()
