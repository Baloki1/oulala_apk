import io
import json
import unittest
from urllib.error import HTTPError
from unittest.mock import MagicMock, patch

from gemini_api import GeminiAPIError, generate_content


class GeminiApiTests(unittest.TestCase):
    @patch("gemini_api.urlopen")
    def test_generate_content_success(self, mock_urlopen):
        mock_response = MagicMock()
        mock_response.__enter__.return_value.read.return_value = json.dumps({
            "candidates": [{
                "content": {
                    "parts": [{"text": "Bonjour"}, {"text": " monde"}]
                }
            }]
        }).encode("utf-8")
        mock_urlopen.return_value = mock_response

        result = generate_content("secret", "gemini-2.5-flash", [{"role": "user", "parts": [{"text": "Salut"}]}])

        self.assertEqual(result, "Bonjour\n monde")

    @patch("gemini_api.urlopen")
    def test_generate_content_http_error(self, mock_urlopen):
        error_payload = json.dumps({"error": {"message": "quota exceeded"}}).encode("utf-8")
        mock_urlopen.side_effect = HTTPError(
            url="https://example.test",
            hdrs={},
            code=429,
            msg="Too Many Requests",
            fp=io.BytesIO(error_payload),
        )

        with self.assertRaises(GeminiAPIError):
            generate_content("secret", "gemini-2.5-flash", [])

    def test_missing_api_key(self):
        with self.assertRaises(GeminiAPIError):
            generate_content("", "gemini-2.5-flash", [])


if __name__ == "__main__":
    unittest.main()
